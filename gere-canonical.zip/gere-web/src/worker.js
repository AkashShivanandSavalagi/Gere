// GERE — Cloudflare Worker (Free Plan $0): static assets + API + WebSocket routing
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    // CORS
    const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors });

    // Health
    if (path === '/api/health') return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json', ...cors } });

    // Create room
    if (path === '/api/room/create' && request.method === 'POST') {
      const body = await request.json();
      const code = genCode();
      const id = env.GERE_ROOM.idFromName(code);
      const stub = env.GERE_ROOM.get(id);
      const r = await stub.fetch(new Request('https://do/init', { method: 'POST', body: JSON.stringify({ code, host: body, origin: url.origin }) }));
      const d = await r.json();
      return new Response(JSON.stringify({ code, inviteUrl: `${url.origin}/?join=${code}`, ...d }), { headers: { 'Content-Type': 'application/json', ...cors } });
    }

    // Submit review
    if (path === '/api/review/submit' && request.method === 'POST') {
      const body = await request.json();
      const id = env.GERE_REVIEWS.idFromName('global');
      const stub = env.GERE_REVIEWS.get(id);
      const r = await stub.fetch(new Request('https://do/review', { method: 'POST', body: JSON.stringify(body) }));
      return new Response(await r.text(), { headers: { 'Content-Type': 'application/json', ...cors } });
    }

    // Get reviews
    if (path === '/api/review/get') {
      const id = env.GERE_REVIEWS.idFromName('global');
      const stub = env.GERE_REVIEWS.get(id);
      const r = await stub.fetch(new Request('https://do/get'));
      return new Response(await r.text(), { headers: { 'Content-Type': 'application/json', ...cors } });
    }

    // WebSocket upgrade for online rooms
    if (request.headers.get('Upgrade') === 'websocket') {
      const m = path.match(/^\/ws\/room\/([A-HJ-NP-Z2-9]{6})$/);
      if (m) {
        const id = env.GERE_ROOM.idFromName(m[1]);
        return env.GERE_ROOM.get(id).fetch(request);
      }
    }

    // Static assets fallback
    return env.ASSETS.fetch(request);
  }
};

const C = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function genCode() { const b = new Uint8Array(6); crypto.getRandomValues(b); let c = ''; for (let i = 0; i < 6; i++) c += C[b[i] % C.length]; return c; }
