// GERE — GereRoom Durable Object: server-authoritative, SQLite, WebSocket Hibernation, anti-cheat
// Board: 9 nodes indexed 0-8. NO move limit. Win = 3-in-a-row.
const ADJ = [[1,3,4],[0,2,4],[1,4,5],[0,4,6],[0,1,2,3,5,6,7,8],[2,4,8],[3,4,7],[4,6,8],[4,5,7]];
const WINS = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const DEADLINE = 21 * 60 * 1000;

export class GereRoom {
  constructor(state, env) {
    this.state = state; this.storage = state.storage; this.env = env;
    this.state.setWebSocketAutoResponse(new WebSocketRequestResponsePair('hb', JSON.stringify({ type: 'hb' })));
  }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/init' && request.method === 'POST') return this.init(request);
    if (request.headers.get('Upgrade') === 'websocket') return this.upgrade(request);
    return new Response('Not found', { status: 404 });
  }

  async init(request) {
    const b = await request.json();
    this.code = b.code; this.host = b.host; this.origin = b.origin;
    await this.storage.put('room', { code: this.code, host: this.host, origin: this.origin, createdAt: Date.now() });
    this.state.storage.setAlarm(Date.now() + 25 * 60 * 1000);
    return new Response(JSON.stringify({ ok: true }));
  }

  async upgrade(request) {
    const url = new URL(request.url);
    const name = url.searchParams.get('name') || 'Player';
    const color = url.searchParams.get('color') || '#1c1917';
    const role = url.searchParams.get('role');

    // Origin validation
    const origin = request.headers.get('Origin');
    const room = await this.storage.get('room');
    if (!room) return new Response('Room not found', { status: 404 });
    if (origin && !origin.includes('localhost') && !origin.includes('workers.dev') && origin !== room.origin) {
      return new Response('Origin rejected', { status: 403 });
    }

    const players = (await this.storage.get('players')) || {};
    let pid;
    if (role === 'P1' && players.P1) pid = 'P1';
    else if (role === 'P2' && players.P2) pid = 'P2';
    else if (!players.P1) { pid = 'P1'; players.P1 = { name, color, presence: 'ONLINE', hb: Date.now() }; }
    else if (!players.P2) { pid = 'P2'; players.P2 = { name, color, presence: 'ONLINE', hb: Date.now() }; await this.startMatch(room, players); }
    else return new Response('ROOM_FULL', { status: 403 });
    await this.storage.put('players', players);

    const pair = new WebSocketPair();
    const ws = pair[1];
    this.state.acceptWebSocket(ws);
    ws.serializeAttachment({ pid });
    const ms = await this.storage.get('matchState');
    if (ms) ws.send(JSON.stringify({ type: 'state', state: ms, role: pid }));
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  async startMatch(room, players) {
    const board = new Array(9).fill(null);
    const ms = {
      status: 'PLACEMENT', turn: 0, board,
      p1: { name: players.P1.name, color: players.P1.color, pawns: 0, moves: 0 },
      p2: { name: players.P2.name, color: players.P2.color, pawns: 0, moves: 0 },
      winner: null, winLine: null, history: [], version: 1,
      clock: room.host.clockType !== 'NONE' ? { type: room.host.clockType, ms: room.host.clockMs, startedAt: null, p1Rem: room.host.clockMs, p2Rem: room.host.clockMs, anchor: null } : null,
    };
    await this.storage.put('matchState', ms);
    await this.state.storage.deleteAlarm();
    this.state.storage.setAlarm(Date.now() + DEADLINE);
    this.broadcast({ type: 'start', state: ms });
  }

  async webSocketMessage(ws, msg) {
    let m; try { m = JSON.parse(msg); } catch { return; }
    if (msg.length > 1024) { ws.send(JSON.stringify({ type: 'error', error: 'Too large' })); return; }
    if (m.type === 'hb') return;
    // Rate limit
    const now = Date.now();
    this._mt = (this._mt || []).filter(t => now - t < 5000);
    if (this._mt.length >= 10) { ws.send(JSON.stringify({ type: 'error', error: 'Rate limited' })); return; }
    this._mt.push(now);

    const att = ws.serializeAttachment();
    const pid = att?.pid;
    if (!pid) { ws.send(JSON.stringify({ type: 'error', error: 'Not authed' })); return; }

    const ms = await this.storage.get('matchState');
    if (!ms || ms.winner !== null) { ws.send(JSON.stringify({ type: 'error', error: 'No match' })); return; }
    // Turn check (server-authoritative)
    const myTurn = ms.turn === 0 ? 'P1' : 'P2';
    if (pid !== myTurn) { ws.send(JSON.stringify({ type: 'error', error: 'Not your turn' })); return; }

    if (m.type === 'PLACE') {
      const node = m.node;
      if (ms.status !== 'PLACEMENT') { ws.send(JSON.stringify({ type: 'error', error: 'Not placement' })); return; }
      if (typeof node !== 'number' || node < 0 || node > 8) { ws.send(JSON.stringify({ type: 'error', error: 'Bad node' })); return; }
      if (ms.board[node] !== null) { ws.send(JSON.stringify({ type: 'error', error: 'Occupied' })); return; }
      const pIdx = pid === 'P1' ? 'p1' : 'p2';
      if (ms[pIdx].pawns >= 3) { ws.send(JSON.stringify({ type: 'error', error: 'Max pawns' })); return; }
      ms.board[node] = pid;
      ms[pIdx].pawns++;
      ms.version++;
      if (ms.clock && !ms.clock.startedAt) { ms.clock.startedAt = Date.now(); ms.clock.anchor = Date.now(); }
      const wl = checkWin(ms.board, pid);
      if (wl) { ms.winner = pid; ms.winLine = wl; await this.save(ms); return; }
      if (ms.p1.pawns === 3 && ms.p2.pawns === 3) { ms.status = 'MOVEMENT'; }
      ms.turn = ms.turn === 0 ? 1 : 0;
      await this.save(ms);
    } else if (m.type === 'MOVE') {
      const from = m.from, to = m.to;
      if (ms.status !== 'MOVEMENT') { ws.send(JSON.stringify({ type: 'error', error: 'Not movement' })); return; }
      if (typeof from !== 'number' || typeof to !== 'number' || from < 0 || from > 8 || to < 0 || to > 8) { ws.send(JSON.stringify({ type: 'error', error: 'Bad node' })); return; }
      if (ms.board[from] !== pid) { ws.send(JSON.stringify({ type: 'error', error: 'Not your pawn' })); return; }
      if (ms.board[to] !== null) { ws.send(JSON.stringify({ type: 'error', error: 'Occupied' })); return; }
      if (!ADJ[from].includes(to)) { ws.send(JSON.stringify({ type: 'error', error: 'Not adjacent' })); return; }
      // Clock consumption
      if (ms.clock?.type === 'SEPARATE' && ms.clock.anchor) {
        const el = Date.now() - ms.clock.anchor;
        if (pid === 'P1') ms.clock.p1Rem -= el; else ms.clock.p2Rem -= el;
        ms.clock.anchor = Date.now();
      }
      ms.board[from] = null; ms.board[to] = pid;
      ms[pid === 'P1' ? 'p1' : 'p2'].moves++;
      ms.version++;
      const wl = checkWin(ms.board, pid);
      if (wl) { ms.winner = pid; ms.winLine = wl; await this.save(ms); return; }
      ms.turn = ms.turn === 0 ? 1 : 0;
      if (ms.clock?.type === 'SEPARATE') ms.clock.anchor = Date.now();
      await this.save(ms);
    } else if (m.type === 'RESIGN') {
      ms.winner = pid === 'P1' ? 'P2' : 'P1';
      await this.save(ms);
    }
  }

  async save(ms) {
    await this.storage.put('matchState', ms);
    this.broadcast({ type: 'state', state: ms });
    if (ms.winner) { this.broadcast({ type: 'end', state: ms }); this.state.storage.setAlarm(Date.now() + 60000); }
  }

  broadcast(msg) { const d = JSON.stringify(msg); for (const ws of this.state.getWebSockets()) { try { ws.send(d); } catch {} } }

  async webSocketClose(ws) {
    const a = ws.serializeAttachment();
    if (a?.pid) {
      const ps = await this.storage.get('players');
      if (ps) { ps[a.pid].presence = 'OFFLINE'; await this.storage.put('players', ps); this.broadcast({ type: 'presence', player: a.pid, presence: 'OFFLINE' }); }
    }
  }
  async webSocketError(ws) { await this.webSocketClose(ws); }

  async alarm() {
    const ms = await this.storage.get('matchState');
    if (!ms || ms.winner) { await this.storage.deleteAll(); return; }
    if (ms.clock?.startedAt && Date.now() - ms.clock.startedAt >= DEADLINE) {
      if (ms.clock.type === 'SEPARATE') {
        if (ms.clock.p1Rem > ms.clock.p2Rem) ms.winner = 'P1';
        else if (ms.clock.p2Rem > ms.clock.p1Rem) ms.winner = 'P2';
      }
      await this.save(ms); return;
    }
    if (ms.clock?.type === 'SEPARATE' && ms.clock.anchor) {
      const rem = (ms.turn === 0 ? ms.clock.p1Rem : ms.clock.p2Rem) - (Date.now() - ms.clock.anchor);
      if (rem <= 0) { ms.winner = ms.turn === 0 ? 'P2' : 'P1'; await this.save(ms); return; }
      this.state.storage.setAlarm(Date.now() + 5000);
    }
  }
}

function checkWin(board, pid) {
  for (const w of WINS) if (board[w[0]] === pid && board[w[1]] === pid && board[w[2]] === pid) return w;
  return null;
}
