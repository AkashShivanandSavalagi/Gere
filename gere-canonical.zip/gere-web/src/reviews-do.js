// GERE — GereReviews Durable Object: stores player ratings in SQLite
export class GereReviews {
  constructor(state, env) { this.state = state; this.storage = state.storage; }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/review' && request.method === 'POST') {
      const b = await request.json();
      const rating = Math.max(1, Math.min(5, parseInt(b.rating) || 5));
      const name = (b.name || '').toString().slice(0, 24).replace(/[<>]/g, '');
      const desc = (b.desc || '').toString().slice(0, 300).replace(/[<>]/g, '');
      const reviews = (await this.storage.get('reviews')) || [];
      reviews.push({ rating, name, desc, ts: Date.now() });
      await this.storage.put('reviews', reviews);
      return new Response(JSON.stringify({ ok: true }));
    }
    if (url.pathname === '/get') {
      const reviews = (await this.storage.get('reviews')) || [];
      const avg = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : '0.0';
      return new Response(JSON.stringify({ reviews, avg, count: reviews.length }));
    }
    return new Response('Not found', { status: 404 });
  }
}
