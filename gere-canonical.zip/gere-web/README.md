# ಗೆರೆ — GERE

A strategic two-player board game. Think · Move · Win.

## Run Locally (VS Code)
1. Open the `public/` folder in VS Code
2. Right-click `index.html` → **Open with Live Server**
3. Game opens at `http://localhost:5500`

## Deploy to Cloudflare Workers ($0 Free Plan)
```bash
npm install -g wrangler
wrangler login
wrangler secret put SESSION_SECRET
wrangler deploy
```

## Deploy to GitHub Pages
1. Push `public/` contents to a GitHub repo root
2. Settings → Pages → Source: Deploy from branch → `main`
3. Live at `https://YOUR_USERNAME.github.io/REPO_NAME/`

## Game Rules
- 3×3 board, 9 nodes, 3 pawns per player
- Phase 1: Placement (alternate placing pawns)
- Phase 2: Movement (move along connected lines)
- Win: 3 pawns in a straight line (horizontal, vertical, diagonal)
- No move limit — matches end on Win, Timer expiry, or 21-min deadline
