// GERE — Main: bootstrap, state store, screen routing, lifecycle
import { createMatch, placePawn, movePawn, restartMatch, legalDests, isOver, roundDisplay, ADJ, CLOCK_PRESETS, CLOCK_LIST, PAWN_COLORS, BOARD_SURFACES, C_IVORY, C_OBSIDIAN, VICTORY_DELAY, PAWNS_PER } from './engine.js';
import { chooseMove, choosePlacement } from './ai.js';
import { icon, pawnHTML, boardSVG, clockHTML, emblemHTML, themeToggleHTML } from './ui.js';
import { toggleTheme } from './theme.js';

const app = document.getElementById('app');
const subs = new Set();
let S = {
  screen: 'splash', splashDone: false,
  setup: { mode:'LOCAL', difficulty:'MEDIUM', p1n:'', p1c:C_IVORY, p2n:'', p2c:C_OBSIDIAN, locked:true, clockType:'NONE', clockMs:CLOCK_PRESETS.FIVE_MIN, boardSurface:0 },
  gs: null, sel: null, legalDests: [], statusMsg: '', aiThinking: false, lastErr: null,
  vPending: false, vVisible: false, vHold: false, matchEnd: null, vTimer: null,
  rating: 0, reviewDesc: '', reviewName: '', avgRating: '0.0', reviewCount: 0,
};

function set(p) { S = {...S, ...p}; subs.forEach(fn => fn(S)); }
function subscribe(fn) { subs.add(fn); }

function resolveName(raw, fb) { const t=(raw||'').trim(); return !t ? fb : t.length>16 ? t.slice(0,16) : t; }
function deriveStatus(gs) {
  if (gs.status==='PLACEMENT') return `${gs.players[gs.turn].name}, place your ${gs.players[gs.turn].pawns+1===1?'1st':gs.players[gs.turn].pawns+1===2?'2nd':'3rd'} pawn`;
  if (gs.status==='MOVEMENT') return `${gs.players[gs.turn].name} turn`;
  if (gs.winner!==null) return `${gs.players[gs.winner].name} wins!`;
  return '';
}

// Actions
function goHome() { if (S.vTimer) clearTimeout(S.vTimer); stopTick(); set({screen:'home', gs:null, sel:null, legalDests:[], statusMsg:'', aiThinking:false, lastErr:null, vPending:false, vVisible:false, vHold:false, matchEnd:null, vTimer:null}); }
function selectMode(mode) { set({setup:{...S.setup, mode, p2n:'', p2c:C_OBSIDIAN, locked:mode==='COMPUTER', clockType:mode==='COMPUTER'?'NONE':S.setup.clockType}, screen:'setup'}); }
function updateSetup(p) { set({setup:{...S.setup, ...p}}); }
function startMatch() {
  const s=S.setup; const isComp=s.mode==='COMPUTER';
  const p1n=resolveName(s.p1n,'P1');
  const p2n=isComp?(s.locked?'CPU':resolveName(s.p2n,'CPU')):resolveName(s.p2n,'P2');
  const p2c=isComp&&s.locked?C_OBSIDIAN:s.p2c;
  const gs=createMatch({p1n,p1c:s.p1c,p2n,p2c,clockType:s.clockType,clockMs:s.clockMs,boardSurface:s.boardSurface});
  if (S.vTimer) clearTimeout(S.vTimer);
  set({screen:'game', gs, sel:null, legalDests:[], statusMsg:deriveStatus(gs), aiThinking:false, lastErr:null, vPending:false, vVisible:false, vHold:false, matchEnd:null, vTimer:null});
}
function restart() {
  if (!S.gs) return; if (S.vTimer) clearTimeout(S.vTimer); stopTick();
  const f=restartMatch(S.gs);
  set({gs:f, sel:null, legalDests:[], statusMsg:deriveStatus(f), aiThinking:false, lastErr:null, vPending:false, vVisible:false, vHold:false, matchEnd:null, vTimer:null});
}
function clickNode(n) {
  const gs=S.gs; if (!gs||isOver(gs)||S.aiThinking) return;
  if (S.setup.mode==='COMPUTER' && gs.turn===1) return; // AI turn lock
  if (gs.status==='PLACEMENT') {
    const r=placePawn(gs,n); if(!r.ok){set({lastErr:r.e});return;}
    set({gs:r.state, sel:null, legalDests:[], statusMsg:deriveStatus(r.state), lastErr:null});
    if(isOver(r.state)){startVictory();return;} maybeAI(r.state);
    return;
  }
  if (gs.status==='MOVEMENT') {
    if (gs.board[n]===gs.turn) { set({sel:n, legalDests:legalDests(gs,n), lastErr:null}); return; }
    if (S.sel!=null && S.legalDests.includes(n)) {
      const r=movePawn(gs,S.sel,n); if(!r.ok){set({lastErr:r.e});return;}
      set({gs:r.state, sel:null, legalDests:[], statusMsg:deriveStatus(r.state), lastErr:null});
      if(isOver(r.state)){startVictory();return;} maybeAI(r.state);
      return;
    }
    set({sel:null, legalDests:[]});
  }
}
function startVictory() {
  if (S.vTimer) clearTimeout(S.vTimer); stopTick();
  set({vPending:true, vVisible:false, vHold:false, matchEnd:Date.now(), vTimer:null});
  const id=setTimeout(()=>{ if(!S.vHold) set({vVisible:true, vPending:false, vTimer:null}); }, VICTORY_DELAY);
  set({vTimer:id});
}
function holdStart() { if(S.vPending&&!S.vHold){if(S.vTimer)clearTimeout(S.vTimer); set({vHold:true, vTimer:null});} }
function holdEnd() {
  if(!S.vPending||!S.vHold) return;
  const rem=VICTORY_DELAY-(Date.now()-(S.matchEnd||0));
  set({vHold:false});
  if(rem<=0) set({vVisible:true, vPending:false});
  else { const id=setTimeout(()=>set({vVisible:true, vPending:false, vTimer:null}), rem); set({vTimer:id}); }
}
function maybeAI(gs) {
  const s=S.setup;
  if (s.mode!=='COMPUTER'||gs.turn!==1) return;
  if (gs.status!=='PLACEMENT'&&gs.status!=='MOVEMENT') return;
  set({aiThinking:true});
  setTimeout(()=>{
    const cur=S.gs; if(!cur||isOver(cur)||cur.turn!==1){set({aiThinking:false});return;}
    let ns;
    if (cur.status==='PLACEMENT') {
      const pos=choosePlacement(cur,1,s.difficulty); if(pos===null){set({aiThinking:false});return;}
      const r=placePawn(cur,pos); if(!r.ok){set({aiThinking:false});return;} ns=r.state;
    } else {
      const mv=chooseMove(cur,1,s.difficulty); if(!mv){set({aiThinking:false});return;}
      const r=movePawn(cur,mv.from,mv.to); if(!r.ok){set({aiThinking:false});return;} ns=r.state;
    }
    set({gs:ns, aiThinking:false, sel:null, legalDests:[], statusMsg:deriveStatus(ns), lastErr:null});
    if(isOver(ns)){startVictory();return;}
    if((ns.status==='PLACEMENT'||ns.status==='MOVEMENT')&&ns.turn===1) maybeAI(ns);
  }, 480);
}

// Clock tick
let tickId=null;
function startTick(){ if(tickId) return; tickId=setInterval(()=>{ if(S.screen==='game'&&S.gs?.clock?.startedAt&&!isOver(S.gs)) render(); else stopTick(); }, 100); }
function stopTick(){ if(tickId){clearInterval(tickId); tickId=null;} }

// Color pick (FIXED: target-aware)
function colorPick(hex, taken, target) {
  if (hex===taken) return;
  if (target==='p1') updateSetup({p1c:hex});
  else updateSetup({p2c:hex});
}

// Rating
function setRating(n) { set({rating:n}); }
async function submitReview() {
  try {
    const r = await fetch('/api/review/submit', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ rating:S.rating, name:S.reviewName, desc:S.reviewDesc }) });
    if (r.ok) { alert('Thank you for rating Gere!'); fetchReviews(); }
  } catch(e) { alert('Could not submit review (offline).'); }
}
async function fetchReviews() {
  try {
    const r = await fetch('/api/review/get');
    if (r.ok) { const d = await r.json(); set({avgRating:d.avg, reviewCount:d.count}); }
  } catch(e) {}
}

// Render
function renderSplash() {
  return `<div class="screen splash active">
    <div class="brand-kn kn-title">ಗೆರೆ</div>
    <div class="brand-en">GERE</div>
    <div class="brand-tag">THINK · MOVE · WIN</div>
    <button class="btn btn-accent" style="margin-top:20px" onclick="window.__gere_enter()">ENTER</button>
  </div>`;
}

function renderHome() {
  const stars = [1,2,3,4,5].map(n => `<span class="star ${n<=S.rating?'filled':''}" onclick="window.__gere_setRating(${n})">★</span>`).join('');
  return `<div class="screen home active">
    <div class="home-topbar"><img src="./assets/gere-logo.png" alt="GERE" class="logo-corner"/>${themeToggleHTML()}</div>
    <div class="home-inner">
      ${emblemHTML()}
      <div class="brand-kn kn-title" style="font-size:36px">ಗೆರೆ</div>
      <div class="brand-en">GERE</div>
      <div class="brand-tag">THINK · MOVE · WIN</div>
      <div class="mode-grid">
        <button class="mode-card" onclick="window.__gere_selectMode('LOCAL')"><span class="icon">${icon('users',16)}</span><span class="label">LOCAL MULTIPLAYER</span><span class="desc">Two players, one device</span></button>
        <button class="mode-card" onclick="window.__gere_selectMode('COMPUTER')"><span class="icon">${icon('cpu',16)}</span><span class="label">PLAY VS AI</span><span class="desc">Easy / Medium / Hard / Impossible</span></button>
        <button class="mode-card disabled"><span class="icon">${icon('globe',16)}</span><span class="label">ONLINE MULTIPLAYER</span><span class="desc">Coming soon</span></button>
      </div>
      <div class="rate-section">
        <h3 style="font-size:10px;letter-spacing:0.16em;color:var(--text-muted);text-transform:uppercase;margin-bottom:6px;text-align:center">RATE GERE</h3>
        <div class="stars-row">${stars}</div>
        <div class="vibe-chips">
          <span class="vibe-chip">Clean</span><span class="vibe-chip">Strategic</span><span class="vibe-chip">Classic</span><span class="vibe-chip">Premium</span><span class="vibe-chip">Smooth</span>
        </div>
        <textarea class="text-input" style="width:100%;min-height:40px;resize:vertical;margin:4px 0" maxlength="300" placeholder="Share your experience…" oninput="window.__gere_setReviewDesc(this.value)">${S.reviewDesc}</textarea>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <input class="text-input" style="flex:1;margin-right:6px" type="text" maxlength="24" placeholder="Name (optional)" value="${S.reviewName}" oninput="window.__gere_setReviewName(this.value)"/>
          <button class="btn btn-accent" onclick="window.__gere_submitReview()">SUBMIT</button>
        </div>
        <div class="avg-rating" style="text-align:center;margin-top:4px">Average: ${S.avgRating}★ (${S.reviewCount} reviews)</div>
      </div>
    </div>
  </div>`;
}

function renderSetup(s) {
  const isComp=s.mode==='COMPUTER';
  const locked=isComp&&s.locked;
  const p2c=locked?C_OBSIDIAN:s.p2c;
  const p2n=locked?'CPU':s.p2n;
  const differ=s.p1c!==p2c;
  let diffH='';
  if (isComp) {
    const D=['EASY','MEDIUM','HARD','IMPOSSIBLE'];
    const desc={EASY:'Takes wins and blocks, otherwise random.',MEDIUM:'Takes wins, blocks, controls centre.',HARD:'Minimax alpha-beta, 7-ply search.',IMPOSSIBLE:'Deepest 13-ply search, nearly unbeatable.'};
    diffH=`<div class="setup-section"><h3 class="section-title">DIFFICULTY</h3><div class="diff-row">${D.map(d=>`<button class="diff-btn ${s.difficulty===d?'active':''}" onclick="window.__gere_updateSetup({difficulty:'${d}'})">${d}</button>`).join('')}</div><p class="setup-desc">${desc[s.difficulty]}</p></div>`;
  }
  let clockH='';
  if (!isComp) {
    clockH=`<div class="setup-section"><h3 class="section-title">TIME CONTROL</h3>
    <div class="clock-type-row"><button class="clock-type-btn ${s.clockType==='NONE'?'active':''}" onclick="window.__gere_updateSetup({clockType:'NONE'})">None</button><button class="clock-type-btn ${s.clockType==='COMBINED'?'active':''}" onclick="window.__gere_updateSetup({clockType:'COMBINED'})">Combined</button><button class="clock-type-btn ${s.clockType==='SEPARATE'?'active':''}" onclick="window.__gere_updateSetup({clockType:'SEPARATE'})">Separate</button></div>
    ${s.clockType!=='NONE'?`<div class="clock-presets">${CLOCK_LIST.map(({k,l})=>`<button class="clock-preset-btn ${s.clockMs===CLOCK_PRESETS[k]?'active':''}" onclick="window.__gere_updateSetup({clockMs:${CLOCK_PRESETS[k]}})">${l}</button>`).join('')}</div>`:''}
    ${s.clockType!=='NONE'?`<p class="setup-desc">${s.clockType==='COMBINED'?'Shared countdown—zero ends in a draw.':'Each player runs their own clock—active turn ticks, zero loses.'}<br>Maximum match limit: 21 minutes.</p>`:''}
    </div>`;
  }
  const cGrid=(sel,taken,target)=>`<div class="chip-grid">${PAWN_COLORS.map(c=>`<button class="color-chip ${sel===c.h?'active':''} ${taken===c.h?'taken':''}" style="background:${c.h}" ${taken===c.h?'disabled':''} onclick="window.__gere_colorPick('${c.h}','${taken}','${target}')" title="${c.n}"></button>`).join('')}</div>`;
  const sGrid=()=>`<div class="chip-grid surface">${BOARD_SURFACES.map((c,i)=>`<button class="surface-chip ${s.boardSurface===i?'active':''}" style="background:${c.bg}" onclick="window.__gere_updateSetup({boardSurface:${i}})" title="${c.n}"></button>`).join('')}</div>`;
  const lockH=isComp?`<div style="display:flex;align-items:center;justify-content:space-between;background:var(--surface-sunken);border-radius:5px;padding:4px 6px"><span style="font-size:9px;color:var(--text-secondary)">${locked?icon('lock',10)+' Locked':icon('unlock',10)+' Customizable'}</span><button class="switch ${locked?'':'on'}" onclick="window.__gere_updateSetup({locked:${!locked}})"><span class="switch-knob"></span></button></div>`:'';
  return `<div class="screen setup active">
    <div class="setup-header"><button class="icon-btn" onclick="window.__gere_goHome()">${icon('back',14)}</button><div style="font-size:10px;font-weight:600;letter-spacing:0.1em;color:var(--accent-active)">${isComp?'VS AI':'LOCAL'}</div><div style="width:30px"></div></div>
    ${diffH}${clockH}
    <div class="setup-section"><h3 class="section-title">PLAYER 1</h3><div class="player-card"><div class="pawn-prev">${pawnHTML(s.p1c)}</div><div class="player-fields"><label class="field-label">Name <em>(optional)</em></label><input class="text-input" type="text" maxlength="16" value="${s.p1n}" placeholder="P1" oninput="window.__gere_updateSetup({p1n:this.value})"/><label class="field-label">Pawn colour</label>${cGrid(s.p1c,null,'p1')}</div></div></div>
    <div class="setup-section"><h3 class="section-title">${isComp?'COMPUTER':'PLAYER 2'}</h3><div class="player-card"><div class="pawn-prev">${pawnHTML(p2c)}</div><div class="player-fields">${lockH}<label class="field-label">Name <em>(optional)</em></label><input class="text-input" type="text" maxlength="16" value="${p2n}" placeholder="${isComp?'CPU':'P2'}" ${locked?'disabled':''} oninput="window.__gere_updateSetup({p2n:this.value})"/><label class="field-label">Pawn colour</label>${cGrid(p2c,s.p1c,'p2')}</div></div></div>
    <div class="setup-section"><h3 class="section-title">BOARD SURFACE</h3>${sGrid()}</div>
    <button class="btn btn-accent" style="width:100%;padding:10px" ${!differ?'disabled':''} onclick="window.__gere_startMatch()">START MATCH</button>
    ${!differ?'<p style="color:var(--danger);font-size:9px;text-align:center;margin-top:3px">Different colours required.</p>':''}
  </div>`;
}

function renderGame(s) {
  const gs=s.gs; if(!gs) return '';
  const over=isOver(gs);
  const phase=gs.status==='PLACEMENT'?'PLACEMENT':gs.status==='MOVEMENT'?'MOVEMENT':'COMPLETE';
  const pp=(i)=>{const p=gs.players[i];const act=gs.turn===i&&!over;return `<div class="pp ${act?'active':''}"><div class="pp-head"><span class="pp-swatch" style="background:${p.color}"></span><div style="flex:1;min-width:0"><span class="pp-name">${p.name}</span><span class="pp-tag">Player ${i+1}</span></div>${act?'<span class="pp-turn">TURN</span>':''}</div><div class="pp-stats"><div class="stat"><span class="stat-label">Pawns</span><span class="stat-val">${p.pawns}/3</span></div><div class="stat"><span class="stat-label">Moves</span><span class="stat-val">${p.moves}</span></div></div></div>`;};

  let timers='';
  if(gs.clock?.type==='SEPARATE') timers=`<div class="timers-row">${clockHTML(gs,0)}${clockHTML(gs,1)}</div>`;
  else if(gs.clock?.type==='COMBINED') timers=`<div class="timers-row single">${clockHTML(gs)}</div>`;

  const NC2=[{x:18,y:18},{x:50,y:18},{x:82,y:18},{x:18,y:50},{x:50,y:50},{x:82,y:50},{x:18,y:82},{x:50,y:82},{x:82,y:82}];
  const nodes=NC2.map((c,i)=>{const owner=gs.board[i];const sel=s.sel===i;const legal=s.legalDests.includes(i);const click=!s.aiThinking&&!over&&(owner===gs.turn||legal||owner===null);return `<button class="node-btn ${sel?'sel':''} ${legal?'legal':''}" style="left:${c.x}%;top:${c.y}%" ${click?'':'disabled'} onclick="window.__gere_clickNode(${i})">${owner!==null?pawnHTML(gs.players[owner].color):''}${legal&&owner===null?'<span class="legal-dot"></span>':''}</button>`;}).join('');

  let vHint='';if(s.vPending&&!s.vVisible){const w=gs.winner!==null?`${gs.players[gs.winner].name} wins`:'Draw';vHint=`<div style="position:absolute;bottom:4px;left:50%;transform:translateX(-50%);background:var(--surface-card);border:1px solid var(--accent-border);color:var(--accent-active);padding:4px 10px;border-radius:999px;font-size:10px;font-weight:600;white-space:nowrap;pointer-events:none">${w}</div>`;}
  let vOver='';
  if(s.vVisible){const isW=gs.winner!==null;const wn=isW?gs.players[gs.winner].name:'';const wc=isW?gs.players[gs.winner].color:'var(--accent-active)';vOver=`<div class="go-backdrop"><div class="go-card">${isW?`<div style="color:${wc};margin-bottom:4px">${icon('crown',28)}</div>`:''}<div class="go-title">GAME OVER</div>${isW?`<div class="go-result"><span style="color:${wc}">${wn}</span> wins</div><div class="go-sub">Three pawns in a straight line</div>`:`<div class="go-result" style="color:var(--accent-active)">Draw</div><div class="go-sub">Time expired</div>`}<div class="go-actions"><button class="btn btn-accent" onclick="window.__gere_restart()">${icon('restart',12)} PLAY AGAIN</button><button class="btn btn-ghost" onclick="window.__gere_goHome()">HOME</button></div></div></div>`;}

  if(gs.clock?.startedAt&&!over) startTick();

  const sf=BOARD_SURFACES[gs.boardSurface];
  return `<div class="screen game active">
    <div class="game-topbar"><button class="icon-btn" onclick="window.__gere_goHomeConfirm()">${icon('back',13)}</button><div class="game-phase">ಗೆರೆ | GERE</div><div class="game-topbar-right">
      <select class="text-input" style="font-size:8px;padding:2px 4px;width:auto" onchange="window.__gere_boardSurfaceChange(this.value)">
        ${BOARD_SURFACES.map((b,i)=>`<option value="${i}" ${gs.boardSurface===i?'selected':''}>${b.n}</option>`).join('')}
      </select>
      ${themeToggleHTML()}<button class="icon-btn" onclick="window.__gere_restartConfirm()">${icon('restart',13)}</button>
    </div></div>
    <div class="hud-top">${pp(0)}${pp(1)}</div>
    ${timers}
    <div class="board-center">
      <div class="board-wrap" onpointerdown="window.__gere_holdStart()" onpointerup="window.__gere_holdEnd()" onpointerleave="window.__gere_holdEnd()">
        ${boardSVG(gs, gs.boardSurface)}${nodes}${vHint}
      </div>
      <div class="status-bar" aria-live="polite">
        ${gs.status==='MOVEMENT'?`<span class="round-disp">${roundDisplay(gs)}</span>`:''}
        ${s.aiThinking?`<span class="status-think"><span class="spinner"></span>${gs.players[1].name} thinking…</span>`:`<span class="status-txt">${s.statusMsg}</span>`}
        ${s.lastErr?`<span class="status-err">${s.lastErr}</span>`:''}
      </div>
    </div>
    ${vOver}
  </div>`;
}

function render() {
  let h;
  if (S.screen==='splash') h=renderSplash();
  else if (S.screen==='home') h=renderHome();
  else if (S.screen==='setup') h=renderSetup(S.setup);
  else if (S.screen==='game') h=renderGame(S);
  else h='<div class="screen active"><p>Unknown</p></div>';
  app.innerHTML = `<div class="app-frame">${h}</div>`;
}

// Globals
window.__gere_toggleTheme = toggleTheme;
window.__gere_enter = () => { fetchReviews(); set({screen:'home'}); };
window.__gere_goHome = goHome;
window.__gere_goHomeConfirm = () => { if(S.gs&&!isOver(S.gs)&&!confirm('Leave match?'))return; goHome(); };
window.__gere_selectMode = selectMode;
window.__gere_updateSetup = updateSetup;
window.__gere_startMatch = startMatch;
window.__gere_restart = restart;
window.__gere_restartConfirm = () => { if(S.gs&&!isOver(S.gs)&&!confirm('Restart?'))return; restart(); };
window.__gere_clickNode = clickNode;
window.__gere_holdStart = holdStart;
window.__gere_holdEnd = holdEnd;
window.__gere_colorPick = colorPick;
window.__gere_boardSurfaceChange = (v) => { if(S.gs) { const ns={...S.gs, boardSurface:parseInt(v)}; set({gs:ns}); } };
window.__gere_setRating = setRating;
window.__gere_setReviewDesc = (v) => set({reviewDesc:v});
window.__gere_setReviewName = (v) => set({reviewName:v});
window.__gere_submitReview = submitReview;

// PWA
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});

// Init
subscribe(render);
render();
