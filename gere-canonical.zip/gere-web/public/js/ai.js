// GERE — AI: 4 levels (Easy 25%, Medium 50%, Hard 75%, Impossible 98%) + anti-repetition
import { ADJ, WINS, checkWin, opp, legalMoves } from './engine.js';

export function choosePlacement(state, pid, diff) {
  if (state.status !== 'PLACEMENT') return null;
  const empties = [];
  for (let i = 0; i < 9; i++) if (state.board[i] === null) empties.push(i);
  if (!empties.length) return null;
  const o = opp(pid);
  for (const n of empties) { const b = [...state.board]; b[n] = pid; if (checkWin(b, pid)) return n; }
  for (const n of empties) { const b = [...state.board]; b[n] = o; if (checkWin(b, o)) return n; }
  if (diff === 'EASY') return empties[Math.floor(Math.random() * empties.length)];
  if (empties.includes(4)) return 4;
  return empties.find(n => [0,2,6,8].includes(n)) || empties[0];
}

export function chooseMove(state, pid, diff) {
  if (state.status !== 'MOVEMENT') return null;
  const moves = legalMoves(state, pid);
  if (!moves.length) return null;
  let pref;
  switch (diff) {
    case 'EASY': pref = easyM(state, pid, moves); break;
    case 'MEDIUM': pref = medM(state, pid, moves); break;
    case 'HARD': pref = search(state, pid, moves, 7); break;
    case 'IMPOSSIBLE': pref = impM(state, pid, moves); break;
    default: pref = moves[0];
  }
  return antiRep(state, pid, pref, moves, diff);
}

function easyM(s, p, moves) {
  const o = opp(p);
  const w = moves.find(m => wouldWin(s, p, m)); if (w) return w;
  const t = findThreats(s, o); if (t.length) { const b = moves.find(m => t.includes(m.to)); if (b) return b; }
  return moves[Math.floor(Math.random() * moves.length)];
}
function medM(s, p, moves) {
  const o = opp(p);
  const w = moves.find(m => wouldWin(s, p, m)); if (w) return w;
  const t = findThreats(s, o); if (t.length) { const b = moves.find(m => t.includes(m.to)); if (b) return b; }
  let best = moves[0], bs = -Infinity;
  for (const m of moves) {
    const b = [...s.board]; b[m.from] = null; b[m.to] = p;
    const sc = countThreats(b, p) * 10 - countThreats(b, o) * 8 + (b[4] === p ? 1 : 0);
    if (sc > bs) { bs = sc; best = m; }
  }
  return best;
}
function search(s, p, moves, depth) {
  const o = opp(p);
  let best = moves[0], bs = -Infinity, alpha = -Infinity;
  for (const m of moves) {
    const sim = applyM(s, p, m);
    const sc = -negamax(sim, o, depth-1, -Infinity, -alpha);
    if (sc > bs) { bs = sc; best = m; }
    if (sc > alpha) alpha = sc;
  }
  return best;
}
function impM(s, p, moves) {
  const o = opp(p);
  const w = moves.find(m => wouldWin(s, p, m)); if (w) return w;
  const t = findThreats(s, o); if (t.length) { const b = moves.find(m => t.includes(m.to)); if (b) return b; }
  return search(s, p, moves, 13);
}

function negamax(s, tm, depth, alpha, beta) {
  const w = checkWin(s.board, 0) !== null || checkWin(s.board, 1) !== null;
  if (w) { const win = checkWin(s.board, 0) !== null ? 0 : 1; return (win === tm ? 1 : -1) * (100000 + depth); }
  if (depth <= 0) return evalPos(s, tm);
  const moves = legalMoves(s, tm);
  if (!moves.length) return -negamax({...s, turn: opp(tm)}, opp(tm), depth-1, -beta, -alpha);
  let best = -Infinity, a = alpha;
  for (const m of moves) {
    const sim = applyM(s, tm, m);
    const sc = -negamax(sim, opp(tm), depth-1, -beta, -a);
    if (sc > best) best = sc;
    if (best > a) a = best;
    if (a >= beta) break;
  }
  return best;
}
function evalPos(s, v) {
  const o = opp(v), b = s.board;
  let sc = (countThreats(b, v) - countThreats(b, o)) * 12;
  if (b[4] === v) sc += 8; else if (b[4] === o) sc -= 8;
  for (const c of [0,2,6,8]) { if (b[c] === v) sc += 3; else if (b[c] === o) sc -= 3; }
  return sc;
}
function applyM(s, p, m) {
  const board = [...s.board]; board[m.from] = null; board[m.to] = p;
  const players = [{...s.players[0]}, {...s.players[1]}];
  players[p].moves++;
  const wl = checkWin(board, p);
  return {...s, board, players, turn: opp(p), winLine: wl, winner: wl ? p : null};
}
function wouldWin(s, p, m) { const b = [...s.board]; b[m.from] = null; b[m.to] = p; return checkWin(b, p) !== null; }
function findThreats(s, p) { return legalMoves(s, p).filter(m => wouldWin(s, p, m)).map(m => m.to); }
function countThreats(b, p) {
  let n = 0;
  for (const w of WINS) { let mine = 0, empty = 0; for (const i of w) { if (b[i] === p) mine++; else if (b[i] === null) empty++; } if (mine === 2 && empty === 1) n++; }
  return n;
}

function antiRep(s, p, pref, all, diff) {
  if (wouldWin(s, p, pref)) return pref;
  const o = opp(p);
  const threats = findThreats(s, o);
  if (threats.length && threats.includes(pref.to)) return pref;
  const last = lastMove(s, p);
  const isRev = last && pref.from === last.to && pref.to === last.from;
  const recent = recentHashes(s, 8);
  const isRep = recent.has(hashAfter(s, p, pref));
  if (!isRev && !isRep) return pref;
  const alts = all.filter(m => {
    if (wouldWin(s, p, m)) return true;
    const rev = last && m.from === last.to && m.to === last.from;
    return !rev && !recent.has(hashAfter(s, p, m));
  });
  if (!alts.length) return pref;
  if (diff === 'EASY') return alts[Math.floor(Math.random() * alts.length)];
  if (diff === 'MEDIUM') return medM(s, p, alts);
  return search(s, p, alts, diff === 'IMPOSSIBLE' ? 13 : 7);
}
function lastMove(s, p) {
  for (let i = s.history.length - 1; i >= 0; i--) if (s.history[i].player === p) return s.history[i];
  return null;
}
function hashAfter(s, p, m) {
  const b = [...s.board]; b[m.from] = null; b[m.to] = p;
  return b.map((v, i) => `${i}:${v || '-'}`).join('|');
}
function recentHashes(s, n) {
  const h = new Set();
  if (!s.history.length) return h;
  let board = [...s.board];
  for (let i = s.history.length - 1; i >= Math.max(0, s.history.length - n); i--) {
    const mv = s.history[i];
    board = [...board]; board[mv.to] = null; board[mv.from] = mv.player;
    h.add(board.map((v, i) => `${i}:${v || '-'}`).join('|'));
  }
  return h;
}
