// GERE — Theme toggle (pre-paint guard is in index.html <head>)
export function toggleTheme() {
  const r = document.documentElement;
  const isDark = r.classList.contains('dark');
  const next = isDark ? 'light' : 'dark';
  r.classList.remove('dark', 'light');
  r.classList.add(next);
  r.style.colorScheme = next;
  try { localStorage.setItem('gere-theme', next); } catch (e) {}
}
export function themeLabel() {
  return document.documentElement.classList.contains('dark') ? 'Dark' : 'Light';
}
