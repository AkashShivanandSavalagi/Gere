// GERE — UI Renderer: DOM, icons, pawn HTML, board SVG, clock, emblem, rate widget
import { ADJ, BOARD_SURFACES } from './engine.js';
import { getRem, fmtTime } from './timers.js';
import { themeLabel } from './theme.js';

const I = {
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  cpu:'<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/>',
  globe:'<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/>',
  settings:'<circle cx="12" cy="12" r="3"/><path d="M12 1v3M12 20v3M4.22 4.22l2.12 2.12M17.66 17.66l2.12 2.12M1 12h3M20 12h3M4.22 19.78l2.12-2.12M17.66 6.34l2.12-2.12"/>',
  download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  back:'<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  restart:'<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
  moon:'<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  sun:'<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>',
  crown:'<path d="M2 4l3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14"/>',
  lock:'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  unlock:'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
};
export function icon(n, s=14) {
  return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${I[n]||''}</svg>`;
}

export function pawnHTML(color) {
  const d = mix(color,'#000',0.55), dd = mix(color,'#000',0.78), l = mix(color,'#fff',0.25);
  return `<div class="pawn" style="--pc:${color}"><div class="pawn-shadow"></div><div class="pawn-base" style="background:linear-gradient(to bottom,${d},${dd})"></div><div class="pawn-collar" style="background:linear-gradient(to bottom,${l},${color},${d})"></div><div class="pawn-head" style="background:radial-gradient(circle at 34% 30%,${l},${color} 42%,${d})"></div><div class="pawn-spec"></div></div>`;
}
function mix(h,m,t) { const a=pH(h),b=pH(m); return `rgb(${Math.round(a.r*(1-t)+b.r*t)},${Math.round(a.g*(1-t)+b.g*t)},${Math.round(a.b*(1-t)+b.b*t)})`; }
function pH(h) { const s=h.replace('#',''),f=s.length===3?s.split('').map(c=>c+c).join(''):s,n=parseInt(f,16); return {r:(n>>16)&255,g:(n>>8)&255,b:n&255}; }

// Node centres in 100x100 viewBox (indexed 0-8)
const NC = [
  {x:18,y:18},{x:50,y:18},{x:82,y:18},
  {x:18,y:50},{x:50,y:50},{x:82,y:50},
  {x:18,y:82},{x:50,y:82},{x:82,y:82},
];
const EDGES = [];
{ const seen=new Set(); for(let a=0;a<9;a++) for(const b of ADJ[a]) { const k=a<b?`${a}-${b}`:`${b}-${a}`; if(!seen.has(k)){seen.add(k);EDGES.push({a,b});} } }

export function boardSVG(state, surfaceIdx) {
  const sf = BOARD_SURFACES[surfaceIdx || 0];
  const ws = state.winLine ? new Set(state.winLine) : new Set();
  const lines = EDGES.map(e=>`<line x1="${NC[e.a].x}" y1="${NC[e.a].y}" x2="${NC[e.b].x}" y2="${NC[e.b].y}" stroke="${sf.line}" stroke-width="0.7" stroke-linecap="round" opacity="0.6"/>`).join('');
  const wells = NC.map((c,i) => {
    const w = ws.has(i) ? `stroke="${state.winner===0?'#0d9488':'#0d9488'}" stroke-width="0.8"` : `stroke="rgba(0,0,0,0.3)" stroke-width="0.4"`;
    return `<circle cx="${c.x}" cy="${c.y}" r="5.5" fill="url(#bw)" ${w}/>`;
  }).join('');
  let winL = '';
  if (state.winLine) { const s=NC[state.winLine[0]],e=NC[state.winLine[2]]; winL=`<line x1="${s.x}" y1="${s.y}" x2="${e.x}" y2="${e.y}" stroke="#0d9488" stroke-width="1.5" stroke-linecap="round"/>`; }
  return `<svg class="board-svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
    <defs><linearGradient id="bs" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${sf.bg}"/><stop offset="100%" stop-color="${sf.bg}"/></linearGradient><radialGradient id="bw" cx="0.5" cy="0.4" r="0.65"><stop offset="0%" stop-color="${sf.well}"/><stop offset="100%" stop-color="${sf.well}"/></radialGradient></defs>
    <rect x="0" y="0" width="100" height="100" fill="url(#bs)" rx="2"/>
    <g stroke="${sf.line}" stroke-width="0.7" stroke-linecap="round" opacity="0.6" fill="none">${lines}</g>${wells}${winL}
  </svg>`;
}

export function clockHTML(state, playerIdx) {
  if (!state.clock || state.clock.type === 'NONE') return '';
  const rem = getRem(state.clock, state.turn);
  if (state.clock.type === 'COMBINED') {
    const t = fmtTime(rem.combined);
    const low = rem.combined <= 10000;
    return `<div class="clock ${low?'low':''}"><span class="clock-label">Shared</span><span class="clk-min">${t.min}</span><span class="clk-sec">${t.sec}</span><span class="clk-ten">${t.ten}</span></div>`;
  }
  if (playerIdx === undefined) return '';
  const key = playerIdx === 0 ? 'p0' : 'p1';
  const t = fmtTime(rem[key]);
  const isActive = state.turn === playerIdx && state.winner === null;
  const low = rem[key] <= 10000;
  return `<div class="clock ${isActive?'active':''} ${low?'low':''}"><span class="clock-label">${state.players[playerIdx].name}</span><span class="clk-min">${t.min}</span><span class="clk-sec">${t.sec}</span><span class="clk-ten">${t.ten}</span></div>`;
}

export function emblemHTML() {
  return `<svg class="emblem" viewBox="0 0 100 100">
    <rect x="10" y="10" width="80" height="80" rx="8" fill="var(--surface-card)" stroke="var(--border-subtle)" stroke-width="1"/>
    <g stroke="var(--text-muted)" stroke-width="1" opacity="0.4">
      <line x1="20" y1="20" x2="50" y2="20"/><line x1="50" y1="20" x2="80" y2="20"/>
      <line x1="20" y1="50" x2="50" y2="50"/><line x1="50" y1="50" x2="80" y2="50"/>
      <line x1="20" y1="80" x2="50" y2="80"/><line x1="50" y1="80" x2="80" y2="80"/>
      <line x1="20" y1="20" x2="20" y2="50"/><line x1="20" y1="50" x2="20" y2="80"/>
      <line x1="50" y1="20" x2="50" y2="50"/><line x1="50" y1="50" x2="50" y2="80"/>
      <line x1="80" y1="20" x2="80" y2="50"/><line x1="80" y1="50" x2="80" y2="80"/>
      <line x1="20" y1="20" x2="50" y2="50"/><line x1="50" y1="50" x2="80" y2="80"/>
      <line x1="80" y1="20" x2="50" y2="50"/><line x1="50" y1="50" x2="20" y2="80"/>
    </g>
    <circle cx="50" cy="50" r="5" fill="var(--accent-active)" class="emblem-pawn"/>
    <circle cx="20" cy="20" r="4" fill="var(--text-secondary)" opacity="0.5"/>
    <circle cx="80" cy="80" r="4" fill="var(--text-secondary)" opacity="0.5"/>
  </svg>`;
}

export function themeToggleHTML() {
  const isDark = document.documentElement.classList.contains('dark');
  return `<button class="theme-toggle" onclick="window.__gere_toggleTheme()">${icon(isDark?'moon':'sun',12)}<span>${themeLabel()}</span></button>`;
}
