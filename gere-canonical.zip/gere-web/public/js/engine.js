// GERE — Core Engine: 9 nodes (0-8), 3-pawn placement, unlimited moves, 3-in-a-row win
export const ADJ = [[1,3,4],[0,2,4],[1,4,5],[0,4,6],[0,1,2,3,5,6,7,8],[2,4,8],[3,4,7],[4,6,8],[4,5,7]];
export const WINS = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
export const PAWNS_PER = 3;
export const TOTAL_PAWNS = 6;
export const VICTORY_DELAY = 1450;
export const CLOCK_PRESETS = { TWO_MIN:120000, FIVE_MIN:300000, NINE_MIN:540000, TWELVE_MIN:720000 };
export const CLOCK_LIST = [{k:'TWO_MIN',l:'2 min'},{k:'FIVE_MIN',l:'5 min'},{k:'NINE_MIN',l:'9 min'},{k:'TWELVE_MIN',l:'12 min'}];
export const PAWN_COLORS = [
  {n:'Ivory',h:'#ece8d9'},{n:'Obsidian',h:'#1c1917'},{n:'Teal',h:'#0d9488'},
  {n:'Slate',h:'#475569'},{n:'Sage',h:'#5c7c6a'},{n:'Burgundy',h:'#7c2d3a'},
  {n:'Amber',h:'#9a6a2e'},{n:'Pearl',h:'#c9c4b8'},
];
export const BOARD_SURFACES = [
  {n:'Classic',bg:'#f4efe2',line:'#2a2520',well:'#b8af98'},
  {n:'Walnut',bg:'#3d2817',line:'#d4af37',well:'#5a3a22'},
  {n:'Slate',bg:'#1e293b',line:'#94a3b8',well:'#334155'},
  {n:'Forest',bg:'#1a2e1a',line:'#86efac',well:'#22543f'},
  {n:'Midnight',bg:'#0c0a1a',line:'#a78bfa',well:'#1e1b3a'},
];
export const C_IVORY = '#ece8d9';
export const C_OBSIDIAN = '#1c1917';

export function emptyBoard() { return new Array(9).fill(null); }
export function checkWin(board, pid) {
  for (const w of WINS) if (board[w[0]]===pid && board[w[1]]===pid && board[w[2]]===pid) return w;
  return null;
}
export function opp(p) { return p===0?1:0; }
export function legalMoves(state, pid) {
  if (state.status!=='MOVEMENT' || state.turn!==pid) return [];
  const m=[];
  for (let i=0;i<9;i++) {
    if (state.board[i]!==pid) continue;
    for (const to of ADJ[i]) if (state.board[to]===null) m.push({from:i,to});
  }
  return m;
}
export function legalDests(state, from) {
  if (state.status!=='MOVEMENT'||state.board[from]!==state.turn) return [];
  return ADJ[from].filter(p=>state.board[p]===null);
}
export function isOver(s) { return s.winner!==null; }

export function createMatch(cfg) {
  const clock = cfg.clockType!=='NONE' ? {type:cfg.clockType, ms:cfg.clockMs, startedAt:null, p0Rem:cfg.clockMs, p1Rem:cfg.clockMs, anchor:null} : null;
  return {
    status:'PLACEMENT', turn:0, board:emptyBoard(),
    players:[
      {name:cfg.p1n,color:cfg.p1c,pawns:0,moves:0},
      {name:cfg.p2n,color:cfg.p2c,pawns:0,moves:0},
    ],
    winner:null, winLine:null, history:[], version:1,
    boardSurface: cfg.boardSurface||0, clock,
  };
}
export function placePawn(state, node) {
  if (state.status!=='PLACEMENT') return {ok:false,e:'Not placement phase'};
  if (state.board[node]!==null) return {ok:false,e:'Occupied'};
  if (state.players[state.turn].pawns>=PAWNS_PER) return {ok:false,e:'Max pawns'};
  const ns = clone(state);
  ns.board[node]=state.turn; ns.players[state.turn].pawns++; ns.version++;
  if (ns.clock && !ns.clock.startedAt) { ns.clock.startedAt=Date.now(); ns.clock.anchor=Date.now(); }
  const wl = checkWin(ns.board, state.turn);
  if (wl) { ns.winner=state.turn; ns.winLine=wl; return {ok:true,state:ns}; }
  if (ns.players[0].pawns===3 && ns.players[1].pawns===3) ns.status='MOVEMENT';
  ns.turn = opp(state.turn);
  return {ok:true,state:ns};
}
export function movePawn(state, from, to) {
  if (state.status!=='MOVEMENT') return {ok:false,e:'Not movement phase'};
  if (state.board[from]!==state.turn) return {ok:false,e:'Not your pawn'};
  if (state.board[to]!==null) return {ok:false,e:'Occupied'};
  if (!ADJ[from].includes(to)) return {ok:false,e:'Not adjacent'};
  const ns = clone(state);
  if (ns.clock?.type==='SEPARATE' && ns.clock.anchor) {
    const el = Date.now()-ns.clock.anchor;
    ns.clock[ns.turn===0?'p0Rem':'p1Rem'] -= el; ns.clock.anchor = Date.now();
  }
  ns.board[from]=null; ns.board[to]=state.turn; ns.players[state.turn].moves++; ns.version++;
  const wl = checkWin(ns.board, state.turn);
  if (wl) { ns.winner=state.turn; ns.winLine=wl; return {ok:true,state:ns}; }
  ns.turn = opp(state.turn);
  if (ns.clock?.type==='SEPARATE') ns.clock.anchor = Date.now();
  return {ok:true,state:ns};
}
export function restartMatch(s) {
  return createMatch({p1n:s.players[0].name,p1c:s.players[0].color,p2n:s.players[1].name,p2c:s.players[1].color,clockType:s.clock?.type,clockMs:s.clock?.ms,boardSurface:s.boardSurface});
}
function clone(s) {
  return {...s, board:[...s.board], players:[{...s.players[0]},{...s.players[1]}],
    history:s.history.map(h=>({...h})),
    clock: s.clock?{...s.clock}:null,
    winLine: s.winLine?[...s.winLine]:null};
}
export function roundDisplay(s) {
  const p0m=s.players[0].moves, p1m=s.players[1].moves, c=Math.min(p0m,p1m);
  if (s.status==='PLACEMENT') return '';
  if (s.winner!==null) return p0m>p1m?`CYCLE ${c+1} · 1/2`:`CYCLE ${c} · 2/2`;
  return `CYCLE ${c+1} · ${p0m===p1m?'0/2':'1/2'}`;
}
