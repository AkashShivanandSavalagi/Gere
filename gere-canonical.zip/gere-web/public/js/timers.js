// GERE — Drift-free Timers: Date.now() deltas, background-tab safe
export function getRem(clock, turn) {
  if (!clock || !clock.startedAt) return null;
  if (clock.type === 'COMBINED') {
    let r = clock.ms - (Date.now() - clock.startedAt);
    return { combined: Math.max(0, r) };
  }
  if (clock.type === 'SEPARATE') {
    const r = { p0: clock.p0Rem, p1: clock.p1Rem };
    if (clock.anchor) r[turn===0?'p0':'p1'] = Math.max(0, r[turn===0?'p0':'p1'] - (Date.now() - clock.anchor));
    return r;
  }
  return null;
}
export function fmtTime(ms) {
  if (ms <= 0) return { min: '0', sec: ':00', ten: '.0' };
  const ts = Math.floor(ms / 1000);
  const m = Math.floor(ts / 60), s = ts % 60, t = Math.floor((ms % 1000) / 100);
  return { min: String(m), sec: ':' + String(s).padStart(2,'0'), ten: '.' + t };
}
