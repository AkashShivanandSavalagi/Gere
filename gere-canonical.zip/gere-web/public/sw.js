// GERE — Service Worker (offline caching)
const CACHE = 'gere-v3';
const SHELL = ['./','./index.html','./manifest.json',
  './css/variables.css','./css/base.css','./css/layout.css','./css/components.css',
  './js/main.js','./js/engine.js','./js/timers.js','./js/ai.js','./js/theme.js','./js/ui.js',
  './assets/icon.svg','./assets/icon-192.png','./assets/icon-512.png','./assets/gere-logo.png'];
self.addEventListener('install', e=>{ e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', e=>{ e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n!==CACHE).map(n=>caches.delete(n))))); self.clients.claim(); });
self.addEventListener('fetch', e=>{
  if(e.request.method!=='GET')return;
  e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).then(r=>{
    if(r.ok&&r.type==='basic'){const cp=r.clone();caches.open(CACHE).then(c=>c.put(e.request,cp));}
    return r;
  }).catch(()=>caches.match('./index.html'))));
});
